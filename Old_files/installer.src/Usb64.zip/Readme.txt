KMCS code signed Docking system USB driver

New binary location For Windows 7 x64 only: 

CVisionUsb.SYS built with Windows 7 WDK version 7600.16385, x64 free build environment.


