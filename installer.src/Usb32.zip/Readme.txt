KMCS code signed Docking system USB driver

New binary location For Windows 7

CVisionUsb.SYS built with Windows 7 WDK version 7600.16385, x86 free build environment.


